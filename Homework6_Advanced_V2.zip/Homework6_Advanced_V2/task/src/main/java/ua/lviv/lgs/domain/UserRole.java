package ua.lviv.lgs.domain;

public enum UserRole {
	ADMINISTRATOR, USER;
}
