package ua.lviv.lgs.dao;

import ua.lviv.lgs.domain.Bucket;
import ua.lviv.lgs.shared.AbstractCRUD;

public interface BucketDao extends AbstractCRUD<Bucket>{

}